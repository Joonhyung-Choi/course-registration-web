import React from "react";
import styled from "styled-components";

function SearchCourseFilter(props) {
  return (
    <Wrapper>
      <InnerWrap>필터링기능이야~</InnerWrap>
    </Wrapper>
  );
}

export default SearchCourseFilter;

const Wrapper = styled.div`
  display: flex;
  width: 100%;
  height: auto;
  margin-bottom: 5px;
  justify-content: center;
  align-items: center;
`;
const InnerWrap = styled.div`
  display: flex;
  flex-direction: row;
  width: 100%;
  height: 30px;
  padding:5px;
  border-radius: 10px;
  border: 1px solid #c7c7c7;
  background-color: #e2e2e2; 
`;
// [카테고리] -> 1. 전공/학과 조회  2. 과목검색  3. 이수구분
const DivCategory = styled.div`
`;
const PCategory = styled.p`
`;
const SelCategory = styled.select``;
// 1. 전공/학과 조회
const DivSubjectType = styled.div`
    `;